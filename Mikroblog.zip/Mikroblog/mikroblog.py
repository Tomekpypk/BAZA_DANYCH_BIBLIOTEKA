# mikroblog.py
from app import app, db
from app.models import User, Post, Book, Author, Available,Borrowed

@app.shell_context_processor
def make_shell_context():
    return {
    "db": db,
    "User": User,
    "Post": Post,
    "Book": Book,
    "Author": Author,
    "Available": Available,
    "Borrowed": Borrowed
    }

if __name__ == '__main__':
    app.run()
