from datetime import datetime
from app import db

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), index=True, unique=True)
    email = db.Column(db.String(200), index=True, unique=True)
    password_hash = db.Column(db.String(128))
    posts = db.relationship("Post", backref="author", lazy="dynamic")

    def __str__(self):
        return f"<User {self.username}>"

class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    body = db.Column(db.Text)
    created = db.Column(db.DateTime, index=True, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

    def __str__(self):
        return f"<Post {self.id} {self.body[:50]} ...>"

class Author(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), index=True, unique=True)
    books = db.relationship("Book", backref="author", lazy="dynamic")

    def __str__(self):
        return f"<Author {self.name}>"

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), index=True, unique=True)
    author_id = db.Column(db.Integer, db.ForeignKey('author.id'))
    available = db.relationship("Available", backref="book", lazy="dynamic")
    borrowed = db.relationship("Borrowed", backref="book", lazy="dynamic")

    def __str__(self):
        return f"<Book {self.title}>"

class Available(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'))
    quantity = db.Column(db.Integer)

    def __str__(self):
        return f"<Available {self.quantity} copies of Book {self.book.title}>"

class Borrowed(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.Integer, db.ForeignKey('book.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    borrow_date = db.Column(db.DateTime, index=True, default=datetime.utcnow)

    def __str__(self):
        return f"<Borrowed Book {self.book.title} by {self.user.username} on {self.borrow_date}>"
